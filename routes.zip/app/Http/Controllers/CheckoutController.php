<?php

namespace App\Http\Controllers;

use App\Models\Payment;
use Illuminate\Http\Request;
use Rave;
use App\Order;
use App\Product;
use App\OrderProduct;
use DB;
use App\Company;
use Gloudemans\Shoppingcart\Facades\Cart;
class CheckoutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function initialize(Request $request)
    {
        // dd($request);
        // dd($request->session()->get('total'));

      try  {


            $order = new Order;
            $order->user_id = auth()->user() ? auth()->user()->id : null;

            // $order->billing_name_on_card = $customer->customer_code;
            $order->order_billing_name = $request->firstname;
            $order->order_billing_email = $request->email;
            $order->order_status = 'Not Confirmed';
            $order->order_amount = $request->session()->get('total');

            $order->order_billing_address = $request->address;
            $order->gender = $request->gender;

            $order->order_unique_id = str_replace('.', '',$request->lastname);


            $order->company_name = $request->company_names;

            $order->company_branch_name = $request->branch ?? null;

            $order->delivery_status = $request->delivery;

            $order->save();

            foreach (Cart::content() as $item) {
                $orderproduct = new OrderProduct;
                $orderproduct->order_id = $order->id;
                $orderproduct->product_id = $item->model->id;
                $orderproduct->order_quantity = $item->qty;
                $test =  $item->model->company_id;
                $companies =  Company::where('id', $test)->first();

                $orderproduct->order_companies =  $companies->company_name;

                $orderproduct->save();

            }
            // dd('here');
            // dd($orderproduct);


        $orderamounts =    Product::where('id', $item->model->id)->select('order_amount')->first();

        $orderamount=  $orderamounts->order_amount + 1;
        // dd($orderamount);
          Product::where('id', $item->model->id)->update(['order_amount' => $orderamount]);

        $json_url = "http://api.ebulksms.com:8080/sendsms.json";



                $username = 'fangjennifer911@gmail.com';

                $apikey = 'e5bfae4e1a681efb8ac53ed72f6f2163035fd62b';

                $sendername = substr('KAE', 0, 11);

                $recipients = "08167354743";

                $message = "Hello! You have a NEW ITEM REQUEST";

                $flash = 0;

                    $message = stripslashes($_POST['message']);
              
                $message = substr($message, 0, 260);
            #Use the next line for HTTP POST with JSON
                // $result = $this->useJSON($json_url, $username, $apikey, $flash, $sendername, $message, $recipients);

        //    dd('here');
        } catch (\Exception $ex) {
            return $ex->getMessage();
        }
        Rave::initialize(route('callback'));
    }
    public function callback(Request $request)
    {

        $companies =  Company::all();
        $resp = $request->resp; $body = json_decode($resp, true);
        $txRef = $body['data']['data']['txRef'];
         $data = Rave::verifyTransaction($txRef);
//  dd($data);
                if ($data->status == 'success') {
 $str = $data->data->custname;
 $new_str = substr($str, ($pos = strpos($str, '.')) !== false ? $pos + 0 : 1);

 $allData = DB::table('orders')->where('order_unique_id', str_replace('.', '', $new_str) )->first();

 $total =  $allData->order_amount;

 if($data->data->amount   ==  $total  ){
//  dd($total);
     $status = 'PAID';
    }elseif($data->data->amount   !=  $total ){
        // dd('not comp');
     $status = 'TAMPERED';

    }
 $purchaseId = $allData->order_unique_id ;
//  dd($allData);
//  dd( DB::table('orders')->where('order_unique_id', $new_str)->get());
   DB::table('orders')->where('order_unique_id', $purchaseId)->update(['order_status' => $status , 'ref_id' => $data->data->txref , 'amount_due' => $data->data->amountsettledforthistransaction, 'payment_type' => $data->data->paymenttype ]);
//   dd($allData);
    Cart::destroy();
   return view('thankyou',compact('purchaseId', 'companies'));
    }
    else {

        return view('errors.405',compact( 'companies'));
    }

}
    public function flutterwavelist(Request $request){

        $companies =  Company::all();
        $arrdata = array(
            'seckey'=> 'FLWSECK-92bb220fcf7cb3d30c84f6d0cd43bab5-X'
            );

            $alltransactions = Rave::listTransactions($arrdata) ;

          $foreachtransactions =  $alltransactions->data->transactions;

          return view('transactions',compact('foreachtransactions', 'companies'));

    }





     function useHTTPGet($url, $username, $apikey, $flash, $sendername, $messagetext, $recipients) {
        $query_str = http_build_query(array('username' => $username, 'apikey' => $apikey, 'sender' => $sendername, 'messagetext' => $messagetext, 'flash' => $flash, 'recipients' => $recipients));
        return file_get_contents("{$url}?{$query_str}");
    }



    function useJSON($url, $username, $apikey, $flash, $sendername, $messagetext, $recipients) {
        $gsm = array();
        $country_code = '234';
        $arr_recipient = explode(',', $recipients);
        foreach ($arr_recipient as $recipient) {
            $mobilenumber = trim($recipient);
            if (substr($mobilenumber, 0, 1) == '0'){
                $mobilenumber = $country_code . substr($mobilenumber, 1);
            }
            elseif (substr($mobilenumber, 0, 1) == '+'){
                $mobilenumber = substr($mobilenumber, 1);
            }
            $generated_id = uniqid('int_', false);
            $generated_id = substr($generated_id, 0, 30);
            $gsm['gsm'][] = array('msidn' => $mobilenumber, 'msgid' => $generated_id);
        }
        $message = array(
            'sender' => $sendername,
            'messagetext' => $messagetext,
            'flash' => "{$flash}",
        );

        $request = array('SMS' => array(
                'auth' => array(
                    'username' => $username,
                    'apikey' => $apikey
                ),
                'message' => $message,
                'recipients' => $gsm
        ));
        $json_data = json_encode($request);

        if ($json_data) {
            $response = $this->doPostRequest($url, $json_data, array('Content-Type: application/json'));

            $result = json_decode($response);
            return $result->response->status;
        } else {
            return false;
        }
    }

    //Function to connect to SMS sending server using HTTP POST
function doPostRequest($url, $arr_params, $headers = array('Content-Type: application/x-www-form-urlencoded')) {
    $response = array();
    $final_url_data = $arr_params;

    if (is_array($arr_params)) {
        $final_url_data = http_build_query($arr_params, '', '&');
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $final_url_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_NOSIGNAL, 1);
    curl_setopt($ch, CURLOPT_VERBOSE, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    $response['body'] = curl_exec($ch);
    $response['code'] = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $response['body'];
}


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function show(Payment $payment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function edit(Payment $payment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Payment $payment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Payment $payment)
    {
        //
    }
}
